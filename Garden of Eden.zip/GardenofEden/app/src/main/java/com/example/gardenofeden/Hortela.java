package com.example.gardenofeden;

import static com.example.gardenofeden.MainActivity.beyonce;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Hortela extends AppCompatActivity {

    Button buttonVoltar;
    Button buttonHortela;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hortela);

        buttonVoltar = findViewById(R.id.buttonVoltar);
        buttonHortela = findViewById(R.id.adicionarCebolinha);


        buttonVoltar.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                finish();

            }
        });

        buttonHortela.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (beyonce.contains("Hortelã")){

                }
                else{
                    beyonce.add("Hortelã");
                }


                AlertDialog.Builder adicioneiGostou = new AlertDialog.Builder(Hortela.this);
                adicioneiGostou.setMessage("Esta lista acaba de ficar mais gorda");
                adicioneiGostou.setCancelable(false);
                adicioneiGostou.setPositiveButton("Okay bb", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                    }
                });
                adicioneiGostou.create().show();
            }

        });
    }
}