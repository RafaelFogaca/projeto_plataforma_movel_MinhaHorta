package com.example.gardenofeden;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import java.util.ArrayList;

public class ThirdActivity extends AppCompatActivity {

    ListView lv;
    Button okay;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_third);

        lv = findViewById(R.id.listaPlanta);
        okay = findViewById(R.id.OkBtn2);

        ArrayList<String> listaPlantas = new ArrayList<>();

        listaPlantas.add("Cebolinha");
        listaPlantas.add("Hortelã");
        listaPlantas.add("Babosa");
        listaPlantas.add("Manjericão");

        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this, android.R.layout.simple_list_item_1,listaPlantas);

        lv.setAdapter(adapter);

        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                if(i == 0){
                    Intent cebolinha = new Intent(getApplicationContext(),Cebolinha.class);
                    startActivity(cebolinha);
                }
                else if(i == 1){
                    Intent hortela = new Intent(getApplicationContext(),Hortela.class);
                    startActivity(hortela);
                }
                else if(i == 2){
                    Intent babosa = new Intent(getApplicationContext(),Babosa.class);
                    startActivity(babosa);
                }
                else if(i == 3){
                    Intent manjericao = new Intent(getApplicationContext(),Manjericao.class);
                    startActivity(manjericao);
                }
            }
        });

        okay.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                finish();

            }
        });


    }
}