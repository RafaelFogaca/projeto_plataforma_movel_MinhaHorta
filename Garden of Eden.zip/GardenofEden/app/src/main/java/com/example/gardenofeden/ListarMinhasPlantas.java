package com.example.gardenofeden;

import static com.example.gardenofeden.MainActivity.beyonce;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class ListarMinhasPlantas<valorRecebido, valorRe> extends AppCompatActivity {

    ListView lvsPlantas;
    Button okPlantas;


    @Override
    protected void onStart() {

        super.onStart();
        setContentView(R.layout.activity_listar_minhas_plantas);

        okPlantas = findViewById(R.id.OkBtn);
        lvsPlantas = findViewById(R.id.listaminhasplantas);


        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1,beyonce);

        lvsPlantas.setAdapter(adapter);

        okPlantas.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                finish();
            }
        });

}

}