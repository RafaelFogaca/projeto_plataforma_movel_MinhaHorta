package com.example.gardenofeden;

import static com.example.gardenofeden.MainActivity.beyonce;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

public class MatarPlanta extends AppCompatActivity {

    ListView lvsPlantasmortas;
    Button okPlantas2;


    @Override
    protected void onStart() {

        super.onStart();
        setContentView(R.layout.activity_listar_minhas_plantas);

        AlertDialog.Builder adicioneiGostou2 = new AlertDialog.Builder(MatarPlanta.this);
        adicioneiGostou2.setMessage("Selecione a planta que deseja retirar da sua lista");
        adicioneiGostou2.setCancelable(false);
        adicioneiGostou2.setPositiveButton("Ok, vamos lá rs", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

            }
        });
        adicioneiGostou2.create().show();

        okPlantas2 = findViewById(R.id.OkBtn);
        lvsPlantasmortas = findViewById(R.id.listaminhasplantas);

        lvsPlantasmortas.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                int j;

                if(beyonce != null){
                    for(j=0;j<beyonce.size();j++){
                        if(beyonce.get(i)==beyonce.get(j)){
                            beyonce.remove(i);
                            AlertDialog.Builder adicioneiGostou = new AlertDialog.Builder(MatarPlanta.this);
                            adicioneiGostou.setMessage("Triste morreu :(");
                            adicioneiGostou.setCancelable(false);
                            adicioneiGostou.setPositiveButton("Sem problemas, planto de novo", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    finish();
                                }
                            });
                            adicioneiGostou.create().show();

                        }
                    }
                }
            }
        });


        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1,beyonce);

        lvsPlantasmortas.setAdapter(adapter);

        okPlantas2.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                finish();
            }
        });

    }

}