package com.example.gardenofeden;

import static com.example.gardenofeden.MainActivity.beyonce;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Cebolinha extends AppCompatActivity {

    Button buttonVoltar;
    Button buttonCebolinha;
    String cebolinhaNome;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cebolinha);

        buttonVoltar = findViewById(R.id.buttonVoltar);
        buttonCebolinha = findViewById(R.id.adicionarCebolinha);




        buttonVoltar.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                finish();

            }
        });

        buttonCebolinha.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (beyonce.contains("Cebolinha")){

                }
                else{
                    beyonce.add("Cebolinha");
                }




                AlertDialog.Builder adicioneiGostou = new AlertDialog.Builder(Cebolinha.this);
                adicioneiGostou.setMessage("Esta lista acaba de ficar mais gorda");
                adicioneiGostou.setCancelable(false);
                adicioneiGostou.setPositiveButton("Okay bb", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                    }
                });
                adicioneiGostou.create().show();


            }

        });
    }
};