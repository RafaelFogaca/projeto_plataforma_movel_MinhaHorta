package com.example.gardenofeden;

import static com.example.gardenofeden.MainActivity.beyonce;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Manjericao extends AppCompatActivity {


    Button buttonVoltar;
    Button buttonManjericao;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manjericao);

        buttonVoltar = findViewById(R.id.voltarManjericao);
        buttonManjericao = findViewById(R.id.adicionarManjericao);


        buttonVoltar.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                finish();

            }
        });

        buttonManjericao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (beyonce.contains("Manjericão")){

                }
                else{
                    beyonce.add("Manjericão");
                }


                AlertDialog.Builder adicioneiGostou = new AlertDialog.Builder(com.example.gardenofeden.Manjericao.this);
                adicioneiGostou.setMessage("Esta lista acaba de ficar mais gorda");
                adicioneiGostou.setCancelable(false);
                adicioneiGostou.setPositiveButton("Okay bb", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                    }
                });
                adicioneiGostou.create().show();
            }

        });
    }
}