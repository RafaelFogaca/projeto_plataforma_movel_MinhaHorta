package com.example.gardenofeden;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

public class SecondActivity extends AppCompatActivity {

    Button ImageButton;
    Button btWeb;
    Button btListar;
    Button matar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);


        ImageButton = findViewById(R.id.imagePlanta);
        btWeb = (Button) findViewById(R.id.noticiaWeb);
        btListar = (Button) findViewById(R.id.btMostrarLista);
        matar = (Button) findViewById(R.id.btnMatarplanta);



        ImageButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent thirdActivity = new Intent(getApplicationContext(),ThirdActivity.class);
                startActivity(thirdActivity);

            }
        });

        matar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent listarlista = new Intent(getApplicationContext(),MatarPlanta.class);
                startActivity(listarlista);
            }
        });

        btListar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent listarlista = new Intent(getApplicationContext(),ListarMinhasPlantas.class);
                startActivity(listarlista);
            }
        });




        btWeb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.jardineiro.net/")));
            }
        });


    }
}